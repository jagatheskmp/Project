package com.bestbuy.coreblue.selenium.util;


public class  MagicNumbers {
	
	public static final int TEN_DAYS = 10;
	public static final int X_POSITION = 780;
	public static final int Y_POSITION = 120;
	public static final long FOURTY_SECONDS = 40000;
	public static final long SIXTY_SECONDS = 60000;
	public static final long EIGHTY_SECONDS = 80000;
	public static final long THIRTY_SEC =30;
	public static final long SIXTY =60;
	public static final long HALF_SECONDS = 500;
	public static final long ONE_THOUSAND_SECONDS = 1000;
	public static final long TWO_THOUSAND_SECONDS = 2000;
	public static final long THREE_THOUSAND_SECONDS = 3000;
	public static final long FOUR_THOUSAND_SECONDS = 4000;
	public static final long FIVE_THOUSAND_SECONDS = 5000;
	public static final long SIX_THOUSAND_SECONDS = 6000;
	public static final long SEVEN_THOUSAND_SECONDS = 7000;
	public static final long TEN_THOUSAND_SECONDS = 10000;
	public static final long TWENTY_THOUSAND_SECONDS = 20000;
	public static final long FOURTY_THOUSAND_SECONDS = 40000;
	public static final long SIXY_THOUSAND_SECONDS = 60000;
}
