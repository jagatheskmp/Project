package com.photon.phresco.selenium.util;

import com.thoughtworks.selenium.Selenium;



@SuppressWarnings("serial")
public  class ScreenException extends Exception {

	    public ScreenException(String msg){ 
	    	
	      super(msg); 
	    } 
}
		
		

	

