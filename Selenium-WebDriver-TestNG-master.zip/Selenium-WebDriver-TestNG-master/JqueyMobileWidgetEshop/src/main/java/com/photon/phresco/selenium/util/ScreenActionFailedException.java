

package com.photon.phresco.selenium.util;

@SuppressWarnings("serial")
public class ScreenActionFailedException extends Exception {

	public ScreenActionFailedException(String msg) {
		super(msg);
	}

}
