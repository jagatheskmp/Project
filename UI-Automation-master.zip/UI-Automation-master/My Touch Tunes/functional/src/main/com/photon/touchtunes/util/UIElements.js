
var haveAccount_id	=	"Have an Account";
var next_id			=	"Next";
var close_id		=	"Close";
var newAccount_id	=	"New Account";
var edit_id			=	"Edit";
var blueButton_id	=	"blue btn full";
var playList_id		=	"Playlists";
var create_id		=	"Create";
var playlistTitle	=	"Name Your Playlist";
var done_id			=	"done";
var save_id			=	"Save";
var more_id			=	"More";
var home_id			=	"Home";
var arrowCountry_id =	"arrow wht";
var signout_id		=	"Sign Out";
var registermsg		=	"Rock the Jukebox";
var verify_Login 	=	"MYTOUCH TUNES";