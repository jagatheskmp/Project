#import "../../../../../main/com/photon/touchtunes/util/MainActivity.js"
#import "../../../../../main/com/photon/touchtunes/util/UIElements.js"


var PlaylistName 			=	"MyTouchTunes";
var EditPlaylistName_id  	=	"MyTouchTunes, 0 songs"; 
var EditPlaylistName 		=	"MyTouchTunes";




