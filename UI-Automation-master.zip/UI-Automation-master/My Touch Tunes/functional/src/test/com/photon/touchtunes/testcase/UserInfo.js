#import "../../../../../main/com/photon/touchtunes/util/MainActivity.js"
#import "../../../../../main/com/photon/touchtunes/util/UIElements.js"


var loginUsername		=	"mytouchtunessample";
var loginPassword		=	"mytouchtunes"
var firstName			=	"MYTOUCH";
var lastName			=	"TUNES";
var registerUsername	=	"mytouchtunessample";
var registerPassword    =	"mytouchtunes";
var registerRePassword	=	"mytouchtunes";
var registerEmail		=	"mytouchtunes@touchtunes.com";



