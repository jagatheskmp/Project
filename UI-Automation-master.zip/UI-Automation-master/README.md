UI-Automation
=============

Contains an example test project  and report for same 