/* 
 * Project Name	:	Digital Deals
 * Project Code : 	01683
 * Author		: 	Jaganathan k 	  Email: jaganathan.kamalakannan@photoninfotech.net 
 *		    	  	Karthikeyan S     Email: karthikeyan.shanmugam@photoninfotech.net 
 * Manager		: 	Shivashankari N   Email: shivashankari.n@photon.in
 */

/*Descriptions	: 	User should get navigated to the previous page on tapping the back button from the header. */

#import "Deals_CommonFunctions.js"

function A_SMT_034() {

	startTestCase("A_SMT_034");
	getMainWindow();
	backButtonVerification();

}
A_SMT_034();