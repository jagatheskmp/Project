package com.bestbuy.search.merchandising.service;

import com.bestbuy.search.merchandising.domain.BannerTemplate;

/**
 * @author Kalaiselvi Jaganathan
 *
 */
public interface IBannerTemplateService extends IBaseService<Long,BannerTemplate>{
	
}
