package com.bestbuy.search.merchandising.dao;

import com.bestbuy.search.merchandising.domain.SearchProfile;

/**
 * @author Kalaiselvi Jaganathan
 *
 */
public class SearchProfileDAO extends BaseDAO<Long,SearchProfile> implements ISearchProfileDAO {

}
