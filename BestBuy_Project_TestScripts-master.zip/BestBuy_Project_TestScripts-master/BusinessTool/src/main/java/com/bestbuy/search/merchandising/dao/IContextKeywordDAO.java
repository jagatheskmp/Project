package com.bestbuy.search.merchandising.dao;

import com.bestbuy.search.merchandising.domain.ContextKeyword;

/**
 * @author Kalaiselvi Jaganathan
 * Interface for Context Keywords in Banners
 */
public interface IContextKeywordDAO extends IBaseDAO<Long,ContextKeyword>{
	
}
