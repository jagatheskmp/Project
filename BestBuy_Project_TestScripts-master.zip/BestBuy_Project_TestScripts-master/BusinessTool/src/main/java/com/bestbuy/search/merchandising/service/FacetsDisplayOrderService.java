package com.bestbuy.search.merchandising.service;

import com.bestbuy.search.merchandising.domain.FacetsDisplayOrder;

/**
 * Facets display order service implementation
 * 
 * @author a1003132
 *
 */
public class FacetsDisplayOrderService extends BaseService<Long, FacetsDisplayOrder> 
		implements IFacetsDisplayOrderService {

}
