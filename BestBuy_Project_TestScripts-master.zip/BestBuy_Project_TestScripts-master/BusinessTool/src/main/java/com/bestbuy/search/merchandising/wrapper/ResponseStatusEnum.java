package com.bestbuy.search.merchandising.wrapper;

public enum ResponseStatusEnum {
	ERROR,
	SUCCESS,
	WARNING
}
