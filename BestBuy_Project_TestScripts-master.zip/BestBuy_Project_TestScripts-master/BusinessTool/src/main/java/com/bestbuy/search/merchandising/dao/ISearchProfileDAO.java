package com.bestbuy.search.merchandising.dao;

import com.bestbuy.search.merchandising.domain.SearchProfile;

/**
 * @author Kalaiselvi Jaganathan
 *
 */
public interface ISearchProfileDAO extends IBaseDAO<Long,SearchProfile>{

}
