/**
 * 
 */
package com.bestbuy.search.merchandising.dao;

import com.bestbuy.search.merchandising.domain.SynonymType;



/**
 *  interface that defines the structure of SynonymListType DAO
 * @author Kalaiselvi.Jaganathan
 */
public interface ISynonymTypeDAO extends IBaseDAO<Long,SynonymType> {

}
