/**
 * 
 */
package com.bestbuy.search.merchandising.service;

import com.bestbuy.search.merchandising.domain.SearchProfile;

/**
 *  Implementation of the UsersService
 * @author chanchal kumari
 */

public interface ISearchProfileService extends IBaseService<Long,SearchProfile>  {

}
