package com.bestbuy.search.merchandising.dao;

import com.bestbuy.search.merchandising.domain.AttrValSortType;

/**
 * @author Kalaiselvi Jaganathan
 * CRUD operations for AttrValSortTypeDAO
 */
public class AttrValSortTypeDAO extends BaseDAO<Long,AttrValSortType> implements IAttrValSortTypeDAO {

}
