package com.bestbuy.search.merchandising.dao;

import com.bestbuy.search.merchandising.domain.AttrValSortType;

/**
 * @author Kalaiselvi Jaganathan
 * Interface that defines the structure of AttrValSortType DAO
 */
public interface IAttrValSortTypeDAO extends IBaseDAO<Long,AttrValSortType> {

}
