package com.bestbuy.search.merchandising.dao;

import com.bestbuy.search.merchandising.domain.BannerTemplateMeta;

/**
 * @author Kalaiselvi Jaganathan
 * BannerTemplates
 */
public class BannerTemplateMetaDAO extends BaseDAO<Long,BannerTemplateMeta> implements IBannerTemplateMetaDAO{

}
