package com.bestbuy.search.merchandising.common;

import org.apache.log4j.Logger;
import org.apache.log4j.spi.LoggerFactory;

public class BTLog4JFactory implements LoggerFactory {

  @Override
  public Logger makeNewLoggerInstance(String name) {
    return new BTLogger(name);
  }

}
