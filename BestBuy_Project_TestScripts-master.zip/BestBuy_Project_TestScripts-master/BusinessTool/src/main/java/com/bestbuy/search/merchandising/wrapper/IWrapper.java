/**
 * Sep 10, 2012 File created by Ramiro.Serrato
 */
package com.bestbuy.search.merchandising.wrapper;



/**
 * @author Ramiro.Serrato
 *
 */

public interface IWrapper extends Comparable<IWrapper> {

}
