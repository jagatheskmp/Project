/**
 * 
 */
package com.bestbuy.search.merchandising.dao;

import com.bestbuy.search.merchandising.domain.SynonymType;

/**
 * CRUD operations for SynonymTypeDAO
 * @author a922998
 */
public class SynonymTypeDAO  extends BaseDAO<Long,SynonymType> implements ISynonymTypeDAO {

}
