package com.bestbuy.search.merchandising.service;

import com.bestbuy.search.merchandising.domain.ContextKeyword;

/**
 * @author Kalaiselvi Jaganathan
 *
 */
public interface IContextKeywordService extends IBaseService<Long,ContextKeyword>{
	
}
