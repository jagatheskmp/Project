package com.bestbuy.search.merchandising.dao;

import com.bestbuy.search.merchandising.domain.ContextFacet;

/**
 * @author Kalaiselvi Jaganathan
 * CRUD for Facets in banners
 */
public class ContextFacetDAO extends BaseDAO<Long,ContextFacet> implements IContextFacetDAO{
	
}
