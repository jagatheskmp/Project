package com.bestbuy.search.merchandising.dao;

import com.bestbuy.search.merchandising.domain.BannerTemplate;

/**
 * @author Kalaiselvi Jaganathan
 *
 */
public interface IBannerTemplateDAO extends IBaseDAO<Long,BannerTemplate>{
}
