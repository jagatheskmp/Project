package com.bestbuy.search.merchandising.service;

import com.bestbuy.search.merchandising.domain.FacetsDisplayOrder;

/**
 * Facets display order interface
 * 
 * @author a1003132
 *
 */
public interface IFacetsDisplayOrderService extends IBaseService<Long, FacetsDisplayOrder>{

}
