package com.bestbuy.search.merchandising.dao;

import com.bestbuy.search.merchandising.domain.Context;

/**
 * @author Kalaiselvi Jaganathan
 * Interface for Banners Context
 */
public interface IContextDAO extends IBaseDAO<Long,Context>{
	
}
