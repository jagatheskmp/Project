package com.bestbuy.search.merchandising.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.bestbuy.search.merchandising.dao.BannerTemplateDAO;
import com.bestbuy.search.merchandising.domain.BannerTemplate;

/**
 * @author Kalaiselvi Jaganathan
 * Service for banner HTML template
 */
public class BannerTemplateService extends BaseService<Long,BannerTemplate> implements IBannerTemplateService{
	
	@Autowired
	public void setDao(BannerTemplateDAO dao) {
		this.baseDAO = dao;
	}

}
