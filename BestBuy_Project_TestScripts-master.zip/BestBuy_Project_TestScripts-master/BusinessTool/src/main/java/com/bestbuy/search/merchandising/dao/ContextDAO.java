package com.bestbuy.search.merchandising.dao;

import com.bestbuy.search.merchandising.domain.Context;

/**
 * @author Kalaiselvi Jaganathan
 * CRUD operations for Banners - Context
 */
public class ContextDAO extends BaseDAO<Long,Context> implements IContextDAO{

}
