package com.bestbuy.search.merchandising.service;

import com.bestbuy.search.merchandising.domain.ContextFacet;

/**
 * @author Kalaiselvi Jaganathan
 *
 */
public interface IContextFacetService extends IBaseService<Long,ContextFacet>{

	
}
