/**
 * 
 */
package com.bestbuy.search.merchandising.dao;

import org.springframework.stereotype.Repository;

import com.bestbuy.search.merchandising.domain.Role;

/**
 * @author Sreedhar Patlola
 *
 */
@Repository
public class RoleDAO extends BaseDAO<Long,Role> {

}
