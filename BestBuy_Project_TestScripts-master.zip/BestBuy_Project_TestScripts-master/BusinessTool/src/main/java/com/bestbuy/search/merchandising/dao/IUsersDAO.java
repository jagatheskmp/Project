/**
 * 
 */
package com.bestbuy.search.merchandising.dao;

import com.bestbuy.search.merchandising.domain.Users;

/**
 * @author Kalaiselvi.Jaganathan
 * Interface that defines the structure of Users DAO
 */
public interface IUsersDAO  extends IBaseDAO<String,Users> {

}
