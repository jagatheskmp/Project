package com.bestbuy.search.merchandising.wrapper;

/**
 * @author Kalaiselvi Jaganathan
 *
 */
public class BannerSkuWrapper {
  
  private String skuIds;
  private Long skuPosition;
  
  public String getSkuIds() {
    return skuIds;
  }
  public void setSkuIds(String skuIds) {
    this.skuIds = skuIds;
  }
  public Long getSkuPosition() {
    return skuPosition;
  }
  public void setSkuPosition(Long skuPosition) {
    this.skuPosition = skuPosition;
  }

}
