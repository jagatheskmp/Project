package com.bestbuy.search.merchandising.dao;

import com.bestbuy.search.merchandising.domain.ContextKeyword;
/**
 * @author Kalaiselvi Jaganathan
 * CRUD operatin for Context Keyword in Banners
 */
public class ContextKeywordDAO extends BaseDAO<Long,ContextKeyword> implements IContextKeywordDAO{

}
