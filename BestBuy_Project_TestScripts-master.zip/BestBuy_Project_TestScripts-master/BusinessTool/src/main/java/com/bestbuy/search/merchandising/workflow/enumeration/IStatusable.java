/**
 * Oct 4, 2012 : File created by Ramiro.Serrato for BestBuy-TCS
 */
package com.bestbuy.search.merchandising.workflow.enumeration;

/**
 * @author Ramiro.Serrato
 *
 */
public interface IStatusable {
	public String getName();

	public String toString();
}
