package com.bestbuy.search.merchandising.dao;

import com.bestbuy.search.merchandising.domain.BannerTemplate;

/**
 * @author Kalaiselvi Jaganathan
 * CRUD operations for Banners HTML Template
 */
public class BannerTemplateDAO extends BaseDAO<Long,BannerTemplate> implements IBannerTemplateDAO{
	
}
