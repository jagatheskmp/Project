define(["framework/Base", "abstract/API"], function() {

	Clazz.createPackage("com.common_components.modules.footer.js.api");
	
	Clazz.com.common_components.modules.footer.js.api.FooterAPI = Clazz.extend(Clazz.com.js.abstract.API, {
		
	});
	
	return Clazz.com.common_components.modules.footer.js.api.FooterAPI; 	
});