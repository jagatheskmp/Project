define(["framework/Base", "abstract/API"], function() {

	Clazz.createPackage("com.components.search.js.api"); 

	Clazz.com.components.search.js.api.SearchAPI = Clazz.extend(Clazz.com.js.abstract.API, {
		
	});
	return Clazz.com.components.search.js.api.SearchAPI;
});