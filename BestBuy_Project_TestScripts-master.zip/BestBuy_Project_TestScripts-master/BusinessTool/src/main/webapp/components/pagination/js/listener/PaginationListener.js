define(["framework/Widget"], function() {

	Clazz.createPackage("com.components.pagination.js.listener");

	Clazz.com.components.pagination.js.listener.PaginationListener = Clazz.extend(Clazz.Widget, {

        /***
         * Called in initialization time of this class 
         *
         * @config: global configurations for this class
         */
		initialize : function(config){
			
		},
	});

	return Clazz.com.components.pagination.js.listener.PaginationListener;
});