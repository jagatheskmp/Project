define(["framework/Base", "abstract/API"], function() {

    Clazz.createPackage("com.components.navigation.js.api");

    Clazz.com.components.navigation.js.api.NavigationAPI = Clazz.extend(Clazz.com.js.abstract.API, {
    });

    return Clazz.com.components.navigation.js.api.NavigationAPI;
});