/**
 * 
 */
package com.bestbuy.search.merchandising.service;

import org.apache.log4j.Logger;
import org.junit.Test;

/**
 * @author chanchal kumari
 *
 */
public class RedirectServiceTest {
	
	private final static Logger logger = Logger.getLogger(RedirectServiceTest.class);

	/**
	 * Test method for {@link com.bestbuy.search.merchandising.service.KeywordRedirectService#create(com.bestbuy.search.merchandising.wrapper.RedirectWrapper)}.
	 */
	
	@Test
	public void testCreate() {
		
	}

}
