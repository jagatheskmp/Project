package com.bestbuy.search.merchandising.integration.data;

public class BasePopulator {
	
	  public static final long GLOBAL_SYNONYM_LIST = 1133827231862L;
	  
	  public static final int NO_OF_SYNONYMS = 36000;
	  public static final int NO_OF_TERMS_PER_SYNONYM = 2;
	  
	  public static final int NO_OF_BANNERS = 5500;
	  public static final int NO_OF_BANNER_CONTEXTS = 2;
	  
	  public static final int KEYWORD_REDIRECTS = 5000;
	  
	  public static final int NO_OF_PROMOS = 5000;


}
