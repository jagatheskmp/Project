package com.photon.Helios.testcases;

import java.io.IOException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.photon.Helios.Screens.BaseScreen;
import com.photon.Helios.uiconstants.AmericanEagleData;
import com.photon.Helios.uiconstants.HeliosUiConstants;
import com.photon.Helios.uiconstants.UIConstants;
import com.photon.Helios.uiconstants.UserInfoConstants;

public class AmericanEagleTest {
	private static UIConstants uiConstants;
	private static HeliosUiConstants HeliosUIConstants;
	private static BaseScreen baseScreen;
	private static String methodName;
	private static String selectedBrowser;
	private static AmericanEagleData AeUIConstants;
	private static UserInfoConstants userInfoConstants;
	

	@BeforeTest
	public static void setUp() throws Exception {
		try {
			System.out.println("----------------------Loading AE Website-----------------");
			HeliosUIConstants = new HeliosUiConstants();
			uiConstants = new UIConstants();
			userInfoConstants =new UserInfoConstants();
			AeUIConstants = new AmericanEagleData();
			launchingBrowser();
			
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}

	public static void launchingBrowser() throws Exception {
		try {
			String applicationURL = HeliosUIConstants.PROTOCOL + "://"
					+ HeliosUIConstants.HOST + "." ;
			selectedBrowser = HeliosUIConstants.BROWSER;
			baseScreen = new BaseScreen(selectedBrowser, applicationURL,
					HeliosUIConstants.CONTEXT, AeUIConstants,
					uiConstants,userInfoConstants);
		} catch (Exception exception) {
			exception.printStackTrace();

		}

	}
 @Test
 public void testCreateAccount()
		throws InterruptedException, IOException, Exception {
	try {

		System.out.println("---------testCreateAccount()-------------");
		methodName = Thread.currentThread().getStackTrace()[1].getMethodName();
		
		baseScreen.CreateNewAccount(methodName);
		
		
	} catch (Exception t) {
		t.printStackTrace();

	}
 }

 @Test
 public void testLoginvalidation()
		throws InterruptedException, IOException, Exception {
	try {

		System.out.println("---------LoginValidation()-------------");
		methodName = Thread.currentThread().getStackTrace()[1].getMethodName();
		
		baseScreen.LoginValidation(methodName);
		
		
	} catch (Exception t) {
		t.printStackTrace();

	}
 }
 
 @Test
 public void testMenCatagories()
		throws InterruptedException, IOException, Exception {
	try {

		System.out.println("---------testMenCatagories()-------------");
		methodName = Thread.currentThread().getStackTrace()[1].getMethodName();
		
		baseScreen.MenCategories(methodName);
		
		
	} catch (Exception t) {
		t.printStackTrace();

	}
 }
 @Test
 public void testWoMenCatagories()
		throws InterruptedException, IOException, Exception {
	try {

		System.out.println("---------testWoMenCatagories()-------------");
		methodName = Thread.currentThread().getStackTrace()[1].getMethodName();
		
		baseScreen.WoMenCategories(methodName);
		
		
	} catch (Exception t) {
		t.printStackTrace();

	}
 }


 @Test
 public void testSearchCategories()
		throws InterruptedException, IOException, Exception {
	try {

		System.out.println("---------testWoMenCatagories()-------------");
		methodName = Thread.currentThread().getStackTrace()[1].getMethodName();
		
		baseScreen.SearchCategories(methodName);
		
		
	} catch (Exception t) {
		t.printStackTrace();

	}
 }



 @AfterTest
 public static void tearDown() {
	baseScreen.closeBrowser();
 }

}