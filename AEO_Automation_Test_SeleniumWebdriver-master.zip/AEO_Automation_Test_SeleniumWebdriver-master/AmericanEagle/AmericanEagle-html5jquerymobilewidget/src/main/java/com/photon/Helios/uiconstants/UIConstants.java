package com.photon.Helios.uiconstants;

import java.lang.reflect.Field;

public class UIConstants {
	
	private ReadXMLFile readXml;
	

	public String CONTINUE_SHOPPING_BUTTON="continueShoppingXapth";
	public String CREATE_ACCOUNT_LINK="createAccountLink";
	public String FIRST_NAME ="firstNameXpath";
	public String LAST_NAME ="lastNameXpath";
	public String EMAIL_ADDRESS="emailAddressXapth";
	public String CINFORM_EMAIL_ADDRESS="ConfromEmailAddressXapth";
	public String PASSWORD="passWordXpath";
	public String CONFORM_PASSWORD="ConfromPasswordValue";
	public String BIRTHDAY_MONTH="BirthdayMonthXpath";
	public String BIRTHDAY_DAY ="BirthdayDayXpath";
	public String BIRTHDAY_YEAR="birhdayYearXapth";
	public String BIRTHDAY_DAY_VALUE="birthdayvaluexpath";
	public String BIRTHDAY_YEAR_VALUE="birthdayyearValue";
	public String GENDER ="genderXpath";
	//public String COUNTRY="countryXapth";
	public String ADDRESS1="address1xpath";
	public String ADDRESS2="Address2xpath";
	public String CITY="city";
	public String STATE="state";	
	public String ZIP="zip";	
	public String TERMS_AND_CONDITION="Termsandconditions";
	public String CREATE_ACCOUNT="createAccount";
	
	
	// Login valiable declation
	
	public String  SIGN_LINK="sign_linkXpath";
	public String  EMAIL_ID_LOGIN="emailidXapth";
	public String  PASSWORD_LOGIN="passwordXpath";
	public String  LOGIN_TAB="LoginTabXpath";
	
	
	//Men categories
	
	public String MEN_CLICK="menclickXpath";
	public String MENS_JEANS="menjeansclickXpath";
	public String BOOTCUT_JEAN="bootcuclickxpath";
	public String WAIST_SIZE="waistsizeclick";
	public String INSEAM_SIZE="inseam_size";
	public String ADDTOBLOG="addtoblog";
	public String CHECK_OUT="checkout";
	//WOMAN CATEGORIES
	public String HOMEPAGE="homepagexpath";
	public String MYACCOUNT="myAccountXpath";
	public String WOMAN_CLICK="womanclickXpath";
	public String WOMAN_JEANS="womanJeansXapth";
	public String JEGGING_ANGLE="jeggingAngleXpath";
	public String SIZE="size";
	public String LENGTH="LengthXpath";
	
	// SEARCH PRODUCTS
	public String SEARCH_CLICK="searchclickXpath";
	public String SEARCH="searchxapth";
	public String SPORTS_SHOES="sportsshoesxapth";
	public String SHOE_SIZE="shoesize";
	
	
	public UIConstants() {
		try {
			readXml = new ReadXMLFile();
			readXml.loadUIConstants();
			Field[] arrayOfField1 = super.getClass().getFields();
			Field[] arrayOfField2 = arrayOfField1;
			int i = arrayOfField2.length;
			for (int j = 0; j < i; ++j) {
				Field localField = arrayOfField2[j];
				Object localObject = localField.get(this);
				if (localObject instanceof String)
					localField
							.set(this, readXml.getValue((String) localObject));

			}
		} catch (Exception localException) {
			throw new RuntimeException("Loading "
					+ super.getClass().getSimpleName() + " failed",
					localException);
		}
	}
}
