package com.photon.Helios.Screens;

import java.awt.AWTException;


import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.google.common.base.Function;
import com.photon.Helios.selenium.util.Constants;
import com.photon.Helios.selenium.util.GetCurrentDir;
import com.photon.Helios.selenium.util.ScreenException;
import com.photon.Helios.uiconstants.AmericanEagleData;
import com.photon.Helios.uiconstants.HeliosUiConstants;
import com.photon.Helios.uiconstants.UIConstants;
import com.photon.Helios.uiconstants.UserInfoConstants;


public class BaseScreen {

	private static WebDriver driver;
	private ChromeDriverService chromeService;
	private Log log = LogFactory.getLog("BaseScreen");
	private WebElement element;	
	private AmericanEagleData Aeconstants;
	private UIConstants uiConstants;
	private UserInfoConstants userInfoConstants;
	private static HeliosUiConstants Helios;
	private static final long TIMEOUT=120;
    private Select selectText;
	// private Log log = LogFactory.getLog(getClass());

	public BaseScreen() {

	}

	public BaseScreen(String selectedBrowser, String applicationURL, String applicatinContext, AmericanEagleData Aeconstants, UIConstants uiConstants,UserInfoConstants userInfoConstants)
			throws ScreenException {
	
		this.Aeconstants=Aeconstants;
		this.uiConstants = uiConstants;
		this.userInfoConstants = userInfoConstants;
		
		instantiateBrowser(selectedBrowser, applicationURL, applicatinContext);

	}

	public void instantiateBrowser(String selectedBrowser,
			String applicationURL, String applicationContext)
			throws ScreenException {

		if (selectedBrowser.equalsIgnoreCase(Constants.BROWSER_CHROME)) {
			try {
				// "D:/Selenium-jar/chromedriver_win_19.0.1068.0/chromedriver.exe"
				chromeService = new ChromeDriverService.Builder()
						.usingDriverExecutable(
								new File(getChromeLocation()))
						.usingAnyFreePort().build();	
				
				log.info("-------------***LAUNCHING GOOGLECHROME***--------------");						
				driver=new ChromeDriver(chromeService);
				//driver.manage().window().maximize();
			//	driver = new ChromeDriver(chromeService, chromeOption);
				// driver.manage().timeouts().implicitlyWait(30,
				// TimeUnit.SECONDS);				
				//driver.navigate().to(applicationURL + applicationContext);
				//windowResize();
				driver.manage().window().maximize();
				driver.navigate().to(applicationURL+applicationContext);
			

			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (selectedBrowser.equalsIgnoreCase(Constants.BROWSER_IE)) {
			log.info("---------------***LAUNCHING INTERNET EXPLORE***-----------");
			driver = new InternetExplorerDriver();
			//windowResize();
			driver.manage().window().maximize();
			driver.navigate().to(applicationURL + applicationContext);
		

		} else if (selectedBrowser.equalsIgnoreCase(Constants.BROWSER_FIREFOX)) {
			log.info("-------------***LAUNCHING FIREFOX***--------------");
			driver = new FirefoxDriver();
			driver.manage().window().maximize();
			
			//windowResize();
			driver.navigate().to(applicationURL + applicationContext);

		}

		else if (selectedBrowser.equalsIgnoreCase(Constants.BROWSER_OPERA)) {
			log.info("-------------***LAUNCHING OPERA***--------------");
			// WebDriver driver = new OperaDriver();
			
			 System.out.println("******entering window maximize********");
			  Robot robot; try { robot = new Robot();
			  robot.keyPress(KeyEvent.VK_ALT);
			  robot.keyPress(KeyEvent.VK_SPACE);
			  robot.keyRelease(KeyEvent.VK_ALT);
			  robot.keyRelease(KeyEvent.VK_SPACE);
			  robot.keyPress(KeyEvent.VK_X); robot.keyRelease(KeyEvent.VK_X); }
			  catch (AWTException e) {
			  
			  e.printStackTrace(); }
			  
		
	

		} else {
			throw new ScreenException(
					"------Only FireFox,InternetExplore and Chrome works-----------");
		}

	}
	
	public static void windowResize()
	{
		Helios = new HeliosUiConstants();
		String resolution = Helios.RESOLUTION;		
		if(resolution!=null)
		{
		String[] tokens = resolution.split("x");
		String resolutionX=tokens[0];
		String resolutionY=tokens[1];		
		int x= Integer.parseInt(resolutionX);
		int y= Integer.parseInt(resolutionY);
		Dimension screenResolution = new Dimension(x,y);
		driver.manage().window().setSize(screenResolution);
		}
		else{
			driver.manage().window().maximize();
		}
	}

	/*
	 * public static void windowMaximizeFirefox() {
	 * driver.manage().window().setPosition(new Point(0, 0)); java.awt.Dimension
	 * screenSize = java.awt.Toolkit.getDefaultToolkit() .getScreenSize();
	 * Dimension dim = new Dimension((int) screenSize.getWidth(), (int)
	 * screenSize.getHeight()); driver.manage().window().setSize(dim); }
	 */

	public void closeBrowser() {
		log.info("-------------***BROWSER CLOSING***--------------");
		if (driver != null) {
			driver.quit();
			
			if (chromeService!=null) {				
				
				
			}
		}

	}

	public String getChromeLocation() {
		log.info("getChromeLocation:*****CHROME TARGET LOCATION FOUND***");
		String directory = System.getProperty("user.dir");
		String targetDirectory = getChromeFile();
		String location = directory + targetDirectory;
		return location;
	}

	public String getChromeFile() {
		if (System.getProperty("os.name").startsWith(Constants.WINDOWS_OS)) {
			log.info("*******WINDOWS MACHINE FOUND*************");
			// getChromeLocation("/chromedriver.exe");
			return Constants.WINDOWS_DIRECTORY + "/chromedriver.exe";
		} else if (System.getProperty("os.name").startsWith(Constants.LINUX_OS)) {
			log.info("*******LINUX MACHINE FOUND*************");
			return Constants.LINUX_DIRECTORY_64 + "/chromedriver";
		} else if (System.getProperty("os.name").startsWith(Constants.MAC_OS)) {
			log.info("*******MAC MACHINE FOUND*************");
			return Constants.MAC_DIRECTORY + "/chromedriver";
		} else {
			throw new NullPointerException("******PLATFORM NOT FOUND********");
		}

	}

	public WebElement getXpathWebElement(String xpath) throws Exception {
		log.info("Entering:-----getXpathWebElement-------");
		try {

			element = driver.findElement(By.xpath(xpath));

		} catch (Throwable t) {
			log.info("Entering:---------Exception in getXpathWebElement()-----------");
			t.printStackTrace();

		}
		return element;

	}

	public void getIdWebElement(String id) throws ScreenException {
		log.info("Entering:---getIdWebElement-----");
		try {
			element = driver.findElement(By.id(id));

		} catch (Throwable t) {
			log.info("Entering:---------Exception in getIdWebElement()----------");
			t.printStackTrace();

		}

	}

	public void getcssWebElement(String selector) throws ScreenException {
		log.info("Entering:----------getIdWebElement----------");
		try {
			element = driver.findElement(By.cssSelector(selector));

		} catch (Throwable t) {
			log.info("Entering:---------Exception in getIdWebElement()--------");

			t.printStackTrace();

		}

	}

	public void waitForElementPresent(String locator, String methodName)
			throws Exception {
		try {
			By by=null;
			log.info("Entering:--------waitForElementPresent()--------");
			
			if(locator.startsWith("//")){
				log.info("Entering:--------Xpath checker--------");
				by = By.xpath(locator);	
			}else{
				log.info("Entering:--------Non-Xpath checker----------------");
				by=By.id(locator);
			}
			
			WebDriverWait wait = new WebDriverWait(driver, 20);			
			wait.until(presenceOfElementLocated(by));
			
		}
	
		catch (Exception e) {
			log.info("Entering:------presenceOfElementLocated()-----End"+"--("+ locator +")--");
			File scrFile = ((TakesScreenshot) driver)
					.getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile,
					new File(GetCurrentDir.getCurrentDirectory() + "\\"
							+ methodName + ".png"));
			/*throw new RuntimeException("waitForElementPresent"
					+ super.getClass().getSimpleName() + " failed", e);*/
			Assert.assertNull(scrFile);

		}
	}
	/*public void waitForTextPresent(String text) throws IOException, Exception{
		try{
		log.info("Entering:*********waitForElementPresent()******");
	    //By by= By.linkText(locator);
		WebDriverWait wait=new WebDriverWait(driver, TIMEOUT);
		driver.findElement(By.tagName(text)).getText();
		log.info("Waiting:*************One second***********");
		//wait.until(presenceOfElementLocated(by));
		}catch(Exception e){
			e.printStackTrace();
			//ScreenCapturer();
			
		}
		
	
	}
	*/
public boolean waitForTextPresent(String text) throws InterruptedException, ScreenException {
		
        if (text!= null){
        	
        	for(int i=0;i<40;i++){
        		System.out.println("--for loop---");
        	   if(driver.findElement(By.tagName("body")).getText().contains(text)){
        		  break; 
        	   }else{
        		   if(i==39){
        			   throw new RuntimeException("---- Time out for finding the Text----");
        		   }
        		   System.out.println("-------wating for 1");
        		   Thread.sleep(1000);
        	   }
        	}
          
       
        }
        else
        {
            throw new RuntimeException("---- Text not existed----");
        }
       
        return true;
       
    }    
	
	

	Function<WebDriver, WebElement> presenceOfElementLocated(final By locator) {
		log.info("Entering:------presenceOfElementLocated()-----Start");
		return new Function<WebDriver, WebElement>() {
			public WebElement apply(WebDriver driver) {	
				log.info("Entering:*********presenceOfElementLocated()******End");
				return driver.findElement(locator);

			}

		};

	}
	public void currenDirectory()
	{
	 File dir1 = new File(".");
     File dir2 = new File("..");
     try {
         System.out.println("Current dir : " + dir1.getCanonicalPath());
         System.out.println("Parent  dir : " + dir2.getCanonicalPath());
     } catch (Exception e) {
         e.printStackTrace();
     }
	}
	
	
	/*.......... Create Account........*/
	 public  void CreateNewAccount(String methodName) throws Exception {
		 if (StringUtils.isEmpty(methodName)) {
           methodName = Thread.currentThread().getStackTrace()[1]
                           .getMethodName();
             }
	    	log.info("@AccountCreation::******executing Account creation****");
			try {
				Thread.sleep(3000);
				waitForElementPresent(uiConstants.CONTINUE_SHOPPING_BUTTON,methodName);
				element=getXpathWebElement(uiConstants.CONTINUE_SHOPPING_BUTTON);
				click();
				Thread.sleep(1000);
				
				waitForElementPresent(uiConstants.CREATE_ACCOUNT_LINK,methodName);
				element=getXpathWebElement(uiConstants.CREATE_ACCOUNT_LINK);
				click();
				Thread.sleep(1000);
				
				waitForElementPresent(uiConstants.FIRST_NAME,methodName);
				element=getXpathWebElement(uiConstants.FIRST_NAME);
				click();
				type(Aeconstants.FIRST_NAME);
				Thread.sleep(1000);
				

				waitForElementPresent(uiConstants.LAST_NAME,methodName);
				element=getXpathWebElement(uiConstants.LAST_NAME);
				click();
				type(Aeconstants.LAST_NAME);
				Thread.sleep(1000);

				waitForElementPresent(uiConstants.EMAIL_ADDRESS,methodName);
				element=getXpathWebElement(uiConstants.EMAIL_ADDRESS);
				click();
				type(Aeconstants.EMAIL_ADDRESS);
				Thread.sleep(1000);

				waitForElementPresent(uiConstants.CINFORM_EMAIL_ADDRESS,methodName);
				element=getXpathWebElement(uiConstants.CINFORM_EMAIL_ADDRESS);
				click();
				type(Aeconstants.CINFORM_EMAIL_ADDRESS);
				Thread.sleep(1000);
				

				waitForElementPresent(uiConstants.PASSWORD,methodName);
				element=getXpathWebElement(uiConstants.PASSWORD);
				click();
				type(Aeconstants.PASSWORD);
				Thread.sleep(1000);
				
				waitForElementPresent(uiConstants.CONFORM_PASSWORD,methodName);
				element=getXpathWebElement(uiConstants.CONFORM_PASSWORD);
				click();
				type(Aeconstants.CONFORM_PASSWORD);
				Thread.sleep(1000);
				
				waitForElementPresent(uiConstants.BIRTHDAY_MONTH,methodName);
				element=getXpathWebElement(uiConstants.BIRTHDAY_MONTH);
				click();
			    type(Aeconstants.BIRTHDAY_MONTH);
				Thread.sleep(1000);
				
				waitForElementPresent(uiConstants.BIRTHDAY_DAY,methodName);
				element=getXpathWebElement(uiConstants.BIRTHDAY_DAY);
				click();
				Thread.sleep(1000);
				element=getXpathWebElement(uiConstants.BIRTHDAY_DAY_VALUE);
				click();		
				
				waitForElementPresent("//html/body/ul[2]/li[3]",methodName);
				element=getXpathWebElement("//html/body/ul[2]/li[3]");
				click();
				
				Thread.sleep(1000);
				
				waitForElementPresent(uiConstants.BIRTHDAY_YEAR,methodName);
				element=getXpathWebElement(uiConstants.BIRTHDAY_YEAR);
				click();
				element=getXpathWebElement(uiConstants.BIRTHDAY_YEAR_VALUE);
				click();
				
				waitForElementPresent("//html/body/ul/li[20]",methodName);
				element=getXpathWebElement("//html/body/ul/li[20]");
				click();
				
				waitForElementPresent(uiConstants.GENDER,methodName);
				element=getXpathWebElement(uiConstants.GENDER);
				click();
				Thread.sleep(1000);
				
				
			/*	waitForElementPresent(uiConstants.COUNTRY,methodName);
				element=getXpathWebElement(uiConstants.COUNTRY);
				click();
			    selectText(element, Aeconstants.COUNTRY);
				Thread.sleep(1000);
				*/
				
				waitForElementPresent(uiConstants.ADDRESS1,methodName);
				element=getXpathWebElement(uiConstants.ADDRESS1);
				click();
				type(Aeconstants.ADDRESS1);
				Thread.sleep(1000);
				
				waitForElementPresent(uiConstants.ADDRESS2,methodName);
				element=getXpathWebElement(uiConstants.ADDRESS2);
				click();
				type(Aeconstants.ADDRESS2);
				Thread.sleep(1000);
				
				waitForElementPresent(uiConstants.CITY,methodName);
				element=getXpathWebElement(uiConstants.CITY);
				click();
				type(Aeconstants.CITY);
				Thread.sleep(1000);
				
				waitForElementPresent(uiConstants.STATE,methodName);
				element=getXpathWebElement(uiConstants.STATE);
				click();
				type(Aeconstants.STATE);
				Thread.sleep(1000);
				
				waitForElementPresent(uiConstants.ZIP,methodName);
				element=getXpathWebElement(uiConstants.ZIP);
				click();
				type(Aeconstants.ZIP);
				Thread.sleep(1000);
				
				
				waitForElementPresent(uiConstants.TERMS_AND_CONDITION,methodName);
				element=getXpathWebElement(uiConstants.TERMS_AND_CONDITION);
				click();
				Thread.sleep(1000);
				

				waitForElementPresent(uiConstants.CREATE_ACCOUNT,methodName);
				element=getXpathWebElement(uiConstants.CREATE_ACCOUNT);
				click();
				Thread.sleep(5000);
				boolean text = isTextPresent("Hello");
			
				if(text){
					
					Thread.sleep(1000);
					element=getXpathWebElement("//div[@id='toolLinks']/div/div/span[2]");
					click();
					Thread.sleep(1000);
					waitForElementPresent("//a[contains(text(),'Sign Out')]",methodName);
					element=getXpathWebElement("//a[contains(text(),'Sign Out')]");
					click();
					Thread.sleep(3000);
				}
				else{
					
					Thread.sleep(1000);
					waitForElementPresent("//a[contains(text(),'Close')]",methodName);
					element=getXpathWebElement("//a[contains(text(),'Close')]");
					click();
					Thread.sleep(3000);
					
				}
				
			} catch (InterruptedException e) {
			
				e.printStackTrace();
			}		
	 }
	 
	 public  void LoginValidation(String methodName) throws Exception {
		 if (StringUtils.isEmpty(methodName)) {
           methodName = Thread.currentThread().getStackTrace()[1]
                           .getMethodName();
             }
	    	log.info("@AccountCreation::******executing Login Validation****");
			try {
				
				Thread.sleep(3000);
				waitForElementPresent(uiConstants.SIGN_LINK,methodName);
				element=getXpathWebElement(uiConstants.SIGN_LINK);
				click();
				Thread.sleep(1000);
				
				waitForElementPresent(uiConstants.EMAIL_ID_LOGIN,methodName);
				element=getXpathWebElement(uiConstants.EMAIL_ID_LOGIN);
				click();
				type(Aeconstants.EMAIL_ID_LOGIN);
				Thread.sleep(1000);
				
				waitForElementPresent(uiConstants.PASSWORD_LOGIN,methodName);
				element=getXpathWebElement(uiConstants.PASSWORD_LOGIN);
				click();
				type(Aeconstants.PASSWORD_LOGIN);
				Thread.sleep(1000);
				
				waitForElementPresent(uiConstants.LOGIN_TAB,methodName);
				element=getXpathWebElement(uiConstants.LOGIN_TAB);
				click();
				Thread.sleep(4000);
				
			} catch (InterruptedException e) {
			
				e.printStackTrace();
			}		
	 }
	 
	 public  void MenCategories(String methodName) throws Exception {
		 if (StringUtils.isEmpty(methodName)) {
           methodName = Thread.currentThread().getStackTrace()[1]
                           .getMethodName();
             }
	    	log.info("@AccountCreation::******executing Login Validation****");
			try {
				
				Thread.sleep(3000);
				waitForElementPresent(uiConstants.MEN_CLICK,methodName);
				element=getXpathWebElement(uiConstants.MEN_CLICK);
				click();
				Thread.sleep(1000);
				
				waitForElementPresent(uiConstants.MENS_JEANS,methodName);
				element=getXpathWebElement(uiConstants.MENS_JEANS);
				click();
				Thread.sleep(2000);
				
				waitForElementPresent(uiConstants.BOOTCUT_JEAN,methodName);	
				element=getXpathWebElement(uiConstants.BOOTCUT_JEAN);
				click();
				Thread.sleep(2000);
				
				waitForElementPresent(uiConstants.WAIST_SIZE,methodName);
				element=getXpathWebElement(uiConstants.WAIST_SIZE);
				click();
				Thread.sleep(2000);
				
				waitForElementPresent(uiConstants.INSEAM_SIZE,methodName);
				element=getXpathWebElement(uiConstants.INSEAM_SIZE);
				click();
				Thread.sleep(2000);
				
				waitForElementPresent(uiConstants.ADDTOBLOG,methodName);
				element=getXpathWebElement(uiConstants.ADDTOBLOG);
				click();
				Thread.sleep(3000);
				
				waitForElementPresent(uiConstants.CHECK_OUT,methodName);
				element=getXpathWebElement(uiConstants.CHECK_OUT);
				click();
				Thread.sleep(5000);
			} catch (InterruptedException e) {
			
				e.printStackTrace();
			}		
	 }
	 
	 public  void WoMenCategories(String methodName) throws Exception {
		 if (StringUtils.isEmpty(methodName)) {
           methodName = Thread.currentThread().getStackTrace()[1]
                           .getMethodName();
             }
	    	log.info("@AccountCreation::******executing Login Validation****");
			try {
				
				Thread.sleep(3000);
				waitForElementPresent(uiConstants.HOMEPAGE,methodName);
				element=getXpathWebElement(uiConstants.HOMEPAGE);
				click();
				Thread.sleep(1000);
				
				waitForElementPresent(uiConstants.MYACCOUNT,methodName);
				element=getXpathWebElement(uiConstants.MYACCOUNT);
				click();
				Thread.sleep(3000);
				
				waitForElementPresent(uiConstants.WOMAN_CLICK,methodName);
				element=getXpathWebElement(uiConstants.WOMAN_CLICK);
				click();
				Thread.sleep(1000);
				
				waitForElementPresent(uiConstants.WOMAN_JEANS,methodName);
				element=getXpathWebElement(uiConstants.WOMAN_JEANS);
				click();
				Thread.sleep(2000);
				
				waitForElementPresent(uiConstants.JEGGING_ANGLE,methodName);	
				element=getXpathWebElement(uiConstants.JEGGING_ANGLE);
				click();
				Thread.sleep(2000);
				
				waitForElementPresent(uiConstants.SIZE,methodName);
				element=getXpathWebElement(uiConstants.SIZE);
				click();
				Thread.sleep(2000);
				
				waitForElementPresent(uiConstants.LENGTH,methodName);
				element=getXpathWebElement(uiConstants.LENGTH);
				click();
				Thread.sleep(2000);
				
				waitForElementPresent(uiConstants.ADDTOBLOG,methodName);
				element=getXpathWebElement(uiConstants.ADDTOBLOG);
				click();
				Thread.sleep(3000);
				
				waitForElementPresent(uiConstants.CHECK_OUT,methodName);
				element=getXpathWebElement(uiConstants.CHECK_OUT);
				click();
				Thread.sleep(5000);
			} catch (InterruptedException e) {
			
				e.printStackTrace();
			}		
	 }
	 
	 public  void SearchCategories(String methodName) throws Exception {
		 if (StringUtils.isEmpty(methodName)) {
           methodName = Thread.currentThread().getStackTrace()[1]
                           .getMethodName();
             }
	    	log.info("@AccountCreation::******executing Login Validation****");
			try {
				
				Thread.sleep(3000);
				waitForElementPresent(uiConstants.SEARCH_CLICK,methodName);
				element=getXpathWebElement(uiConstants.SEARCH_CLICK);
				click();
				Thread.sleep(1000);
				element.sendKeys("shoes");
				Thread.sleep(1000);
				
				waitForElementPresent(uiConstants.SEARCH,methodName);
				element=getXpathWebElement(uiConstants.SEARCH);
				click();
				Thread.sleep(2000);
				
				waitForElementPresent(uiConstants.SPORTS_SHOES,methodName);	
				element=getXpathWebElement(uiConstants.SPORTS_SHOES);
				click();
				Thread.sleep(2000);
				
				waitForElementPresent(uiConstants.SHOE_SIZE,methodName);
				element=getXpathWebElement(uiConstants.SHOE_SIZE);
				click();
				Thread.sleep(2000);
				
				waitForElementPresent(uiConstants.ADDTOBLOG,methodName);
				element=getXpathWebElement(uiConstants.ADDTOBLOG);
				click();
				Thread.sleep(3000);
				
				waitForElementPresent(uiConstants.CHECK_OUT,methodName);
				element=getXpathWebElement(uiConstants.CHECK_OUT);
				click();
				Thread.sleep(5000);
			} catch (InterruptedException e) {
			
				e.printStackTrace();
			}		
	 }
	 	
public void click() throws ScreenException {
		log.info("Entering:********click operation start********");
		try {
			element.click();
		} catch (Throwable t) {
			t.printStackTrace();
		}
		log.info("Entering:********click operation end********");

	}
	public void type(String text)throws ScreenException{
		log.info("Entering:********enterText operation start********");
		try{
			
			element.sendKeys(text);
			
		}catch(Throwable t){
			t.printStackTrace();
		}
		log.info("Entering:********enterText operation end********");
	}
	

	public void clear() throws ScreenException {
		log.info("Entering:********clear operation start********");
		try {
			element.clear();
		} catch (Throwable t) {
			t.printStackTrace();
		}
		log.info("Entering:********clear operation end********");

	}



	public void submit() throws ScreenException {
		log.info("Entering:********submit operation start********");
		try {
			element.submit();
		} catch (Throwable t) {
			t.printStackTrace();
		}
		log.info("Entering:********submit operation end********");

	}
	public boolean isTextPresent(String text)
	{
		if(text!=null)
		{
			boolean value=driver.findElement(By.tagName("body")).getText().contains(text);
			System.out.println("--------TextCheck value---->"+text+"------------Result is-------------"+value); 
//			Assert.assertTrue(value);
			return value;
		}
		 else
	        {
	            throw new RuntimeException("---- Text not present----");
	        }
	       
	}
       

	

  public void selectText(WebElement element,String TextValue) throws ScreenException {
	               log.info("Entering:---------get Select Text Webelement---------");
	               try {
	                       Select selObj=new Select(element);
	                       selObj.selectByValue(TextValue);
	               } catch (Throwable t) {
	                       log.info("Entering:--------Exception in SelectextWebElement()-------");

	                       t.printStackTrace();

	               }
	 
	 

       
       
  }
}
