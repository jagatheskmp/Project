package com.photon.Helios.selenium.util;





@SuppressWarnings("serial")
public  class ScreenException extends Exception {

	    public ScreenException(String msg){ 
	    	
	      super(msg); 
	    } 
}
		
		

	

