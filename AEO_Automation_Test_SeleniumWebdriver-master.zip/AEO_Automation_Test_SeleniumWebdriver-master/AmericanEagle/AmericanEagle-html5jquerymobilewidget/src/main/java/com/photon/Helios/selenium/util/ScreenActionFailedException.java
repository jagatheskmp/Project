

package com.photon.Helios.selenium.util;

@SuppressWarnings("serial")
public class ScreenActionFailedException extends Exception {

	public ScreenActionFailedException(String msg) {
		super(msg);
	}

}
