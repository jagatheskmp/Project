package com.photon.Helios.uiconstants;

import java.lang.reflect.Field;

public class AmericanEagleData {

	private ReadXMLFile readXml;
	
	//public String CONTINUE_SHOPPING_BUTTON="continueShoppingButtonValue";
	public String FIRST_NAME="firstnameValue";
	public String LAST_NAME="lastNameValue";
	public String EMAIL_ADDRESS="emailAddressValue";
	public String CINFORM_EMAIL_ADDRESS="conformEmailAddressXpath";
	public String PASSWORD="passwordValue";
	public String CONFORM_PASSWORD="conformPasswordValue";
	public String BIRTHDAY_MONTH ="birthdayMonthValue";
	public String BIRTHDAY_DAY="birthdayDayValue";
	public String BIRTHDAY_YEAR ="BirhdayYearValue";
	//public String COUNTRY="countryValue";
	public String ADDRESS1="address1value";
	public String ADDRESS2="address2value";
	public String CITY="city";
	public String STATE="state";
	public String ZIP="zip";
	
	// Login valiable declaration
	public String EMAIL_ID_LOGIN="EmaliIdLoginValue";
	public String PASSWORD_LOGIN="passwordLoginValue";
	
	

	
	
	
	
	public AmericanEagleData() {
		try {
			readXml = new ReadXMLFile();
			readXml.loadAdminUIData();
			Field[] arrayOfField1 = super.getClass().getFields();
			Field[] arrayOfField2 = arrayOfField1;
			int i = arrayOfField2.length;
			for (int j = 0; j < i; ++j) {
				Field localField = arrayOfField2[j];
				Object localObject = localField.get(this);
				if (localObject instanceof String)
					localField
							.set(this, readXml.getValue((String) localObject));

			}
		} catch (Exception localException) {
			throw new RuntimeException("Loading "
					+ super.getClass().getSimpleName() + " failed",
					localException);
		}
	}
}
