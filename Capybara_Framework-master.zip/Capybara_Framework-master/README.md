Capybara_Framework
==================

Contains an example Test scripts
