package com.example.tests;

public class NH4444444 {
	  public static void main(String a[]){
		 
		    int i,j,k;
		    for(i=4;i>=1;i--)
		    {
		      for(j=4;j>=i;j--)
		        System.out.println(j);
		      for(j=1;j<(i*2)-1;j++)
		    	  System.out.println(i);      
		      for(j=i+1;j<=4;j++)
		    	  System.out.println(j);      
		      System.out.println("\n");
		    }
		    for(i=2;i<=4;i++)
		    {
		      for(j=4;j>=i;j--)
		    	  System.out.println(j);
		      for(j=1;j<(i*2)-1;j++)
		    	  System.out.println(i);      
		      for(j=i+1;j<=4;j++)
		    	  System.out.println(j);      
		      System.out.println("\n");
		    }  
		    
		  }
	  }


