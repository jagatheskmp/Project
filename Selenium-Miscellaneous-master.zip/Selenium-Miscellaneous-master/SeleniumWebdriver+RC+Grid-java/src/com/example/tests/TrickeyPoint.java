package com.example.tests;

public class TrickeyPoint {
	
	public static void main(String arg []){
		String str = null;
		String str1="abc";
		System.out.println(str1.equals("abc") | str.equals(null));
}}