package auto_it;

import java.io.IOException;

import org.testng.annotations.*;

import com.thoughtworks.selenium.DefaultSelenium;
import com.thoughtworks.selenium.SeleneseTestBase;

public class SportingBet extends SeleneseTestBase {
	
	@BeforeClass
	public void setUp()
	{
		selenium=new DefaultSelenium("localhost",4444,"*firefox","https://outlook.sportingbet.com");
		selenium.start();
		selenium.windowMaximize();
	}
	
	@Test
	public void loginTest() throws Exception
	{
		Runtime run = Runtime.getRuntime();
        Process pp=run.exec("D:\\workspace\\AutoIt_Examples\\Login.exe");
		selenium.open("/exchange");
		
		
	}
	
	

}
