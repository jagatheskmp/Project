package auto_it;

import org.openqa.selenium.server.SeleniumServer;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.thoughtworks.selenium.DefaultSelenium;
import com.thoughtworks.selenium.SeleneseTestBase;

public class AlertConf extends SeleneseTestBase {
	
	SeleniumServer server;
	
	@BeforeClass
	public void setUp() throws Exception
	{
		selenium=new DefaultSelenium("localhost",4444,"*firefox","http://mail.yahoo.com");
		server=new SeleniumServer();
		server.start();
		selenium.start();
		selenium.windowMaximize();
	}
	
	@Test
	public void sampleTest() throws Exception
	{
		selenium.open("/");
		selenium.captureScreenshot("C:\\Screenshot\\loginpage.jpg");
		selenium.type("id=username", "veera_bvm");
		selenium.type("id=passwd", "Navane@82yuviraj");
		selenium.click("id=.save");
		selenium.waitForPageToLoad("30000");
		selenium.captureScreenshot("C:\\Screenshot\\mainpage.jpg");
		selenium.chooseOkOnNextConfirmation();
		selenium.click("id=folder_list_empty_bulk");
		selenium.getConfirmation();
		selenium.click("link=Sign Out");
		selenium.waitForPageToLoad("30000");	
		selenium.stop();
		server.stop();
	}
}
