package auto_it;

import java.io.File;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.thoughtworks.selenium.DefaultSelenium;
import com.thoughtworks.selenium.SeleneseTestBase;

public class SelDownload extends SeleneseTestBase {
	
	@BeforeClass
	public void setUp()
	{
		selenium=new DefaultSelenium("localhost",4444,"*firefox","http://seleniumhq.org");
	//	selenium=new DefaultSelenium("localhost",4444,"*firefox","http://mudra.tv/");
		selenium.start();
		selenium.windowMaximize();
	}
	
	@Test
	public void DownloadTest() throws Exception
	{
	
		selenium.open("/download/"); 
		
		Runtime rt = Runtime.getRuntime() ; 

		Process p = rt.exec("D:\\workspace\\AutoIt_Examples\\Download.exe"); 
		try{

		selenium.click("link=2.24.1"); 
		}
		catch(Exception e)
		{
			System.out.println("Download link not available");
			selenium.stop();
			System.exit(0);
		}

		Thread.sleep(30000); 

		File file=new File("C:\\Users\\Thangaraj\\Downloads\\selenium-server-standalone-2.24.1.jar"); 

		Assert.assertTrue(file.exists());

    }
	
	@Test(enabled=false)
	public void UploadTest() throws Exception
	{
		selenium.open("/index.php"); 
		
		Runtime rt = Runtime.getRuntime();
		
		Process prs= rt.exec("D:\\workspace\\AutoIt_Examples\\upload.exe");
		
		selenium.click("name=Image15"); 
		
		Thread.sleep(30000); 
		
		selenium.type("username", "thangaraj");
		
		selenium.type("password", "thangaraj");
		
		selenium.click("action_login");
		  
		Thread.sleep(30000); 
		
		

	}
	
	@AfterClass
	public void tearDown()
	{
		selenium.stop();
	}
}
