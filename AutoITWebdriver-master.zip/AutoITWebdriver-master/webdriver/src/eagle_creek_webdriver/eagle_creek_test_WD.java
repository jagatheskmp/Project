package eagle_creek_webdriver;

	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	//import org.openqa.selenium.ie.InternetExplorerDriver;
	
	import org.testng.Assert;
	import org.testng.annotations.*;

	public class eagle_creek_test_WD { 
	public WebDriver driver;

	@BeforeClass
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver = new ChromeDriver();
		//System.setProperty("webdriver.ie.driver", "D:\\exploredriver.exe");
		// driver = new InternetExplorerDriver();
			}

	@Test
	public void eagle_search_Method() throws Exception {   
		driver.get("http://www.eaglecrk.com");
		Thread.sleep(10000);
		WebElement searchBox = driver.findElement(By.id("searchsubmit"));
		
		searchBox.sendKeys("CRM");
	    searchBox.submit();
	    Thread.sleep(10000);
		Assert.assertEquals("EagleCreek - Search for CRM", driver.getTitle());
	}
	@AfterClass
	public void tearDown() {
	 driver.quit();
		}
	}

