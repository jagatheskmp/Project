package com.photon.phresco.hybrid.test;

@SuppressWarnings("serial")
public class TestException extends Exception {

	public TestException(String exec) {
		super(exec);

	}

}

